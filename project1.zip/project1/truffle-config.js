var HDWalletProvider = require("truffle-hdwallet-provider");
var infura_apikey = "https://ropsten.infura.io/v3/54bde9d5df4844439190fc5481876cd6"; // API Key จาก Infura
var mnemonic = "camp aisle tiger squeeze angry rain fancy fever couple obvious torch gas"; //mnemonic seed จากกระเป๋าของ Ropsten Testnet
module.exports = {
  networks: {
    development: {
      host: "localhost",
      port: 7545,
      network_id: "*" // Match any network id
    },
    ropsten: {
      provider: new HDWalletProvider(mnemonic, infura_apikey),
      network_id: 3
    }
  },
  compilers: {
    solc: {
      version: "0.4.20+commit.3155dd80.Emscripten.clang"
    }
  }
};

